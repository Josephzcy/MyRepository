def PassArrayFromCToPython(Array):
    print ("Shape Of Array:", Array.shape)
    print (Array)


def ArrayListReturn(Array):
	print (Array)
    ArrList = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    Array_A  = np.asarray(ArrList, dtype='float' )
    Array_B  = np.asarray(ArrList, dtype='double')
    return [Array_A, Array_B]